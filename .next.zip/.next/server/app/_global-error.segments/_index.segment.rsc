1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/42879de7b8087bc9.js"],"default"]
3:I[37457,["/_next/static/chunks/42879de7b8087bc9.js"],"default"]
0:{"buildId":"BuX4q3d0Lk6kP9EDk_M4_","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}

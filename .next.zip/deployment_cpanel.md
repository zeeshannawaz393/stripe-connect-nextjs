# Deploying Next.js to cPanel

Since your Next.js app requires a Node.js server (for features like Image Optimization and Server Side Rendering), you cannot simply upload files to `public_html` like a static PHP site. You must use the **"Setup Node.js App"** feature in cPanel.

## Method 1: Using "Setup Node.js App" (Recommended)

This method ensures your app runs exactly as it does on your local machine.

### 1. Build the Project Locally
In your VS Code terminal, run:
```bash
npm run build
```
This creates a `.next` folder.

### 2. Prepare for Upload
Create a `server.js` file in your root folder (next to `package.json`) to act as the entry point for cPanel.

**Create `server.js`:**
```javascript
const { createServer } = require('http');
const { parse } = require('url');
const next = require('next');

const dev = process.env.NODE_ENV !== 'production';
const hostname = 'localhost';
const port = process.env.PORT || 3000;
const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  createServer((req, res) => {
    const parsedUrl = parse(req.url, true);
    handle(req, res, parsedUrl);
  }).listen(port, (err) => {
    if (err) throw err;
    console.log(`> Ready on http://${hostname}:${port}`);
  });
});
```

### 3. ZIP Your Files
Select and ZIP the following files/folders:
- `.next` (Folder)
- `public` (Folder)
- `package.json`
- `server.js` (The file you just created)
- `.env.local` (Your environment variables)

**Do NOT** upload `node_modules`. We will install them on the server.

### 4. Upload to cPanel
1.  Log in to cPanel.
2.  Go to **File Manager**.
3.  Create a folder for your app (e.g., `stripe-app`). **Do not** put it inside `public_html` yet.
4.  Upload and Extract your ZIP file there.

### 5. Configure Node.js in cPanel
1.  Go to cPanel Dashboard → **Software** → **Setup Node.js App**.
2.  Click **Create Application**.
3.  **Python settings**: Leave as is.
4.  **Node.js Version**: Select v18 or v20 (matching your local env).
5.  **Application Mode**: Production.
6.  **Application Root**: `stripe-app` (the folder you created).
7.  **Application URL**: Select your domain (e.g., `yoursite.com`).
8.  **Application Startup File**: `server.js`.
9.  Click **Create**.

### 6. Install Dependencies
1.  Once created, scroll down to the command section.
2.  Click **"Enter to the virtual environment"** (it copies a command to clipboard).
3.  Open **Terminal** in cPanel (or SSH).
4.  Paste the command to enter the environment.
5.  Run: `npm install`

### 7. Restart
Go back to the **Setup Node.js App** page and click **Restart**.

Your app should now be live!

---

## Method 2: Static Export (Only if Node.js is NOT available)

If your host does not support Node.js, you can export as static HTML/CSS/JS.

**Limitations:**
- No Image Optimization (`<Image>` component)
- No API Routes (if you had any)
- No SSR

### 1. Update `next.config.mjs`
```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  images: { unoptimized: true } // Required for static export
};

export default nextConfig;
```

### 2. Build
```bash
npm run build
```
This causes Next.js to generate an `out` folder.

### 3. Upload
Upload the contents of the `out` folder directly to your `public_html` folder in cPanel.
